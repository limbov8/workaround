# DEPRECATED

The [deprecated log](https://www.envoyproxy.io/docs/envoy/latest/version_history/version_history)
for each version can be found in the official Envoy developer documentation.
